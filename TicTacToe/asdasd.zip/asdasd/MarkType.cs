﻿namespace TicTacToe
{
    public enum MarkType
    {
        //None
        Free,
        //O
        Nought,
        //X
        Cross
    }
}
